"use strict";
exports.__esModule = true;
id;
"display" > /pre>
    < script;
src = "diff.js" > /script>
    < script >
;
var color = '', span = null;
var json = require("C:\\Users\\Assaf\\Documents\\tiip191\\ngx-manusctipts-viewer\\src\\api\\manuscripts.json");
var xDelta = 30;
var yDelta = 30;
var chapter_1 = json[0];
var firstPageOfChapter = chapter_1.pages[0];
var fourthPageOfChapter = chapter_1.pages[3];
comaprePageAnnotations(firstPageOfChapter, fourthPageOfChapter, 1);
function comaprePageAnnotations(firstPage, secondPage, version) {
    var firstPageAnnotationLayers = firstPage.version[version].annotationLayer;
    var secondPageAnnotationLayers = secondPage.version[version].annotationLayer;
    if (firstPageAnnotationLayers == undefined || secondPageAnnotationLayers == undefined) {
        return null;
    }
    for (var i = 0; i < firstPageAnnotationLayers.length; i++) {
        for (var j = 0; j < secondPageAnnotationLayers.length; j++) {
            if (!isSameAnnotation(firstPageAnnotationLayers[i], secondPageAnnotationLayers[j])) {
                continue;
            }
            /* We have a possible match, proccess it by diff and keep the result, where? */
            console.log("----Annotation----");
            var diff = JsDiff.diffChars(firstPageAnnotationLayers[i].textNote, secondPageAnnotationLayers[j].textNote), display = document.getElementById('display'), fragment = document.createDocumentFragment();
            diff.forEach(function (part) {
                // green for additions, red for deletions
                // grey for common parts
                color = part.added ? 'green' :
                    part.removed ? 'red' : 'grey';
                span = document.createElement('span');
                span.style.color = color;
                span.appendChild(document
                    .createTextNode(part.value));
                fragment.appendChild(span);
            });
            display.appendChild(fragment);
        }
    }
}
function isSameAnnotation(firstTextBox, secondTextBox) {
    var firstStartPoint = firstTextBox.startPoint;
    var secondStartPoint = secondTextBox.startPoint;
    return (Math.abs(firstStartPoint.x - secondStartPoint.x) < xDelta &&
        Math.abs(firstStartPoint.y - secondStartPoint.y) < yDelta);
}
/script>
    < /body>
    < /html> ;
/* (0,0) is at top left */
