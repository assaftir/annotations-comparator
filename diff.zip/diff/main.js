"use strict";
exports.__esModule = true;
require('colors');
var jsdiff = require('diff');
var json = require("C:\\Users\\Assaf\\Documents\\tiip191\\ngx-manusctipts-viewer\\src\\api\\manuscripts.json");
var xDelta = 30;
var yDelta = 30;
//Pick a chapter
var chapter_1 = json[0];
//Pick page number
var page = chapter_1.pages[0];
//Pick versions to comapre
var versionOne = 1;
var versionTwo = 2;
/* Compare page versions, versionOne vs versionTwo */
var diffs = comaprePageAnnotations(page, versionOne, versionTwo);
/* Print the results */
diffs.forEach(function (str) {
    if (str == "")
        console.log("\n----Annotation----");
    else
        process.stdout.write(str);
});
function comaprePageAnnotations(page, firstVersion, secondVersion) {
    var firstVersionPageAnnotations = page.version[firstVersion].annotationLayer;
    var secondVersionPageAnnotations = page.version[secondVersion].annotationLayer;
    var diffs = [];
    if (firstVersionPageAnnotations == undefined || secondVersionPageAnnotations == undefined) {
        return null;
    }
    for (var i = 0; i < firstVersionPageAnnotations.length; i++) {
        for (var j = 0; j < secondVersionPageAnnotations.length; j++) {
            if (!isSameAnnotation(firstVersionPageAnnotations[i], secondVersionPageAnnotations[j])) {
                continue;
            }
            /* We have a possible match, proccess it by diff and add it to the diffs array */
            var diff = jsdiff.diffChars(firstVersionPageAnnotations[i].textNote, secondVersionPageAnnotations[j].textNote);
            diff.forEach(function (part) {
                var color = part.added ? 'green' :
                    part.removed ? 'red' : 'grey';
                diffs.push(part.value[color]);
            });
            diffs.push("");
        }
    }
    return diffs;
}
function isSameAnnotation(firstTextBox, secondTextBox) {
    var firstStartPoint = firstTextBox.startPoint;
    var secondStartPoint = secondTextBox.startPoint;
    return (Math.abs(firstStartPoint.x - secondStartPoint.x) < xDelta &&
        Math.abs(firstStartPoint.y - secondStartPoint.y) < yDelta);
}
/* (0,0) is at top left */
